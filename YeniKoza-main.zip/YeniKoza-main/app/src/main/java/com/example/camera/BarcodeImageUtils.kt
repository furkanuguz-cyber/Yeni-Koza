package com.example.camera

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object BarcodeImageUtils {

    suspend fun detectBarcodeFromUri(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val image = InputImage.fromFilePath(context, uri)
            val scanner = BarcodeScanning.getClient(
                BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                    .build()
            )

            val task = scanner.process(image)
            val barcodes = com.google.android.gms.tasks.Tasks.await(task)
            barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
        } catch (e: Exception) {
            null
        }
    }

    suspend fun copyImageToAppStorage(context: Context, sourceUri: Uri): Uri? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(sourceUri)
            val labelDir = File(context.filesDir, "labels")
            if (!labelDir.exists()) {
                labelDir.mkdirs()
            }
            val targetFile = File(labelDir, "label_${UUID.randomUUID()}.jpg")
            val outputStream = FileOutputStream(targetFile)

            inputStream?.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            Uri.fromFile(targetFile)
        } catch (e: Exception) {
            sourceUri
        }
    }

    fun createTempPictureUri(context: Context): Uri {
        val tempDir = File(context.cacheDir, "camera_photos")
        if (!tempDir.exists()) {
            tempDir.mkdirs()
        }
        val tempFile = File(tempDir, "temp_label_${System.currentTimeMillis()}.jpg")
        return androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            tempFile
        )
    }
}
