package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {
    @Query("SELECT * FROM stock_items ORDER BY updatedAt DESC")
    fun getAllStockItems(): Flow<List<StockItemEntity>>

    @Query("SELECT * FROM stock_items WHERE barcode = :barcode ORDER BY updatedAt DESC")
    suspend fun getItemsByBarcode(barcode: String): List<StockItemEntity>

    @Query("SELECT * FROM stock_items WHERE location = :location ORDER BY updatedAt DESC")
    fun getItemsByLocation(location: String): Flow<List<StockItemEntity>>

    @Query("SELECT * FROM stock_items WHERE location = :location ORDER BY updatedAt DESC")
    suspend fun getItemsByLocationSync(location: String): List<StockItemEntity>

    @Query("SELECT DISTINCT location FROM stock_items ORDER BY location ASC")
    fun getAllLocations(): Flow<List<String>>

    @Query("SELECT * FROM stock_items WHERE barcode = :barcode AND location = :location LIMIT 1")
    suspend fun findExact(barcode: String, location: String): StockItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: StockItemEntity): Long

    @Query("DELETE FROM stock_items WHERE barcode = :barcode")
    suspend fun deleteByBarcode(barcode: String): Int

    @Query("DELETE FROM stock_items WHERE barcode = :barcode AND location = :location")
    suspend fun deleteByBarcodeAndLocation(barcode: String, location: String): Int

    @Delete
    suspend fun deleteItem(item: StockItemEntity)

    @Query("SELECT COUNT(*) FROM stock_items")
    fun getTotalItemCount(): Flow<Int>

    // Audit Logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentLogs(): Flow<List<AuditLogEntity>>

    @Insert
    suspend fun insertLog(log: AuditLogEntity)

    @Query("DELETE FROM audit_logs")
    suspend fun clearLogs()

    @Query("DELETE FROM stock_items")
    suspend fun clearAllStock()
}
