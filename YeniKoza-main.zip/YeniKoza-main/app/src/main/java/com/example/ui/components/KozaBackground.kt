package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KozaBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF18181D),
                        Color(0xFF101013),
                        Color(0xFF0A0A0C)
                    )
                )
            )
    ) {
        // Subtle ambient warehouse pattern lines
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 48.dp.toPx()
            val lineColor = Color.White.copy(alpha = 0.025f)
            var x = 0f
            while (x < size.width) {
                drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                y += step
            }
        }

        // Left vertical bold white "YENİ KOZA" from bottom to top
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 6.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "Y E N İ   K O Z A",
                color = Color.White.copy(alpha = 0.22f),
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 10.sp,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.graphicsLayer {
                    rotationZ = -90f
                }
            )
        }

        // Center Grand Watermark: Bold White "YENİ KOZA" running from bottom to top
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Y E N İ   K O Z A",
                color = Color.White.copy(alpha = 0.12f),
                fontSize = 54.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 16.sp,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.graphicsLayer {
                    rotationZ = -90f
                }
            )
        }

        // Right vertical bold white "YENİ KOZA" from bottom to top
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(end = 6.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text(
                text = "Y E N İ   K O Z A",
                color = Color.White.copy(alpha = 0.22f),
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 10.sp,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.graphicsLayer {
                    rotationZ = -90f
                }
            )
        }

        // Screen Foreground Content
        content()
    }
}
