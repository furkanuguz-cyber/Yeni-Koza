package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.camera.LiveBarcodeScannerDialog
import com.example.ui.components.AuditLogScreen
import com.example.ui.components.BulkTransferDialog
import com.example.ui.components.GoogleAppsScriptWebView
import com.example.ui.components.InventoryListScreen
import com.example.ui.components.KozaBackground
import com.example.ui.components.YeniKozaCard
import kotlinx.coroutines.launch

@Composable
fun MainAppScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allStock by viewModel.allStockItems.collectAsStateWithLifecycle()
    val allLocations by viewModel.allLocations.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentLogs.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var pendingScannerTarget by remember { mutableStateOf<ScannerTarget?>(null) }

    // Camera permission request launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            pendingScannerTarget?.let { viewModel.openScanner(it) }
        } else {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Barkod okumak için kamera izni gereklidir.")
            }
        }
        pendingScannerTarget = null
    }

    val requestCameraAndOpenScanner = { target: ScannerTarget ->
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            viewModel.openScanner(target)
        } else {
            pendingScannerTarget = target
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFF111113),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF18181C),
                contentColor = Color.White,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = uiState.activeTab == AppTab.MAIN_CARD,
                    onClick = { viewModel.setActiveTab(AppTab.MAIN_CARD) },
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Yeni Koza") },
                    label = { Text("Yeni Koza", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color.White,
                        indicatorColor = Color.White,
                        unselectedIconColor = Color(0xFF9CA3AF),
                        unselectedTextColor = Color(0xFF9CA3AF)
                    ),
                    modifier = Modifier.testTag("nav_yeni_koza")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == AppTab.INVENTORY_LIST,
                    onClick = { viewModel.setActiveTab(AppTab.INVENTORY_LIST) },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Stoklar") },
                    label = { Text("Stoklar", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color.White,
                        indicatorColor = Color.White,
                        unselectedIconColor = Color(0xFF9CA3AF),
                        unselectedTextColor = Color(0xFF9CA3AF)
                    ),
                    modifier = Modifier.testTag("nav_stoklar")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == AppTab.HISTORY,
                    onClick = { viewModel.setActiveTab(AppTab.HISTORY) },
                    icon = { Icon(Icons.Default.History, contentDescription = "Geçmiş") },
                    label = { Text("Geçmiş", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color.White,
                        indicatorColor = Color.White,
                        unselectedIconColor = Color(0xFF9CA3AF),
                        unselectedTextColor = Color(0xFF9CA3AF)
                    ),
                    modifier = Modifier.testTag("nav_gecmis")
                )

                NavigationBarItem(
                    selected = uiState.activeTab == AppTab.WEB_PANEL,
                    onClick = { viewModel.setActiveTab(AppTab.WEB_PANEL) },
                    icon = { Icon(Icons.Default.CloudSync, contentDescription = "Web Panel") },
                    label = { Text("Web Panel", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color.White,
                        indicatorColor = Color.White,
                        unselectedIconColor = Color(0xFF9CA3AF),
                        unselectedTextColor = Color(0xFF9CA3AF)
                    ),
                    modifier = Modifier.testTag("nav_web_panel")
                )
            }
        }
    ) { paddingValues ->
        KozaBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (uiState.activeTab) {
                AppTab.MAIN_CARD -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 480.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            YeniKozaCard(
                                uiState = uiState,
                                locationsList = allLocations,
                                onBarcodeChanged = viewModel::onBarcodeChanged,
                                onLocationChanged = viewModel::onLocationChanged,
                                onPhotoSelected = { uri ->
                                    viewModel.processCapturedPhoto(context, uri)
                                },
                                onClearPhoto = viewModel::clearPhoto,
                                onAssignClick = { viewModel.assignProduct() },
                                onFindClick = viewModel::findLocation,
                                onDeleteClick = viewModel::deleteProduct,
                                onOpenScanner = { target ->
                                    requestCameraAndOpenScanner(target)
                                },
                                onOpenBulkTransfer = {
                                    viewModel.openBulkTransferDialog()
                                }
                            )
                        }
                    }
                }

                AppTab.INVENTORY_LIST -> {
                    InventoryListScreen(
                        items = allStock,
                        locations = allLocations,
                        searchQuery = uiState.searchQuery,
                        selectedLocation = uiState.selectedLocationFilter,
                        onSearchChanged = viewModel::setSearchQuery,
                        onLocationFilterSelected = viewModel::setLocationFilter,
                        onQuantityChange = viewModel::updateQuantity,
                        onDeleteItem = viewModel::deleteSpecificItem,
                        onSelectItemForCard = { item ->
                            viewModel.fillSampleItem(item.barcode, item.location)
                            viewModel.setActiveTab(AppTab.MAIN_CARD)
                        },
                        onShareCsv = {
                            viewModel.shareCsvExport(context)
                        },
                        onOpenBulkTransfer = { loc ->
                            viewModel.openBulkTransferDialog(loc)
                        }
                    )
                }

                AppTab.HISTORY -> {
                    AuditLogScreen(
                        logs = recentLogs
                    )
                }

                AppTab.WEB_PANEL -> {
                    GoogleAppsScriptWebView(
                        url = uiState.googleAppsScriptUrl
                    )
                }
            }
        }
    }

    // Bulk Location Transfer Dialog
    if (uiState.showBulkTransferDialog) {
        BulkTransferDialog(
            sourceLocation = uiState.transferSourceLocation,
            targetLocation = uiState.transferTargetLocation,
            availableLocations = allLocations,
            sourceItems = uiState.transferSourceItems,
            selectedItemIds = uiState.selectedTransferItemIds,
            isTransferring = uiState.isTransferring,
            errorMessage = uiState.transferStatusMessage,
            onSourceChanged = viewModel::setTransferSource,
            onTargetChanged = viewModel::setTransferTarget,
            onOpenScanner = { target ->
                requestCameraAndOpenScanner(target)
            },
            onToggleItemSelection = viewModel::toggleTransferItemSelection,
            onSelectAllToggled = viewModel::toggleSelectAllTransferItems,
            onExecuteTransfer = viewModel::executeBulkTransfer,
            onDismiss = viewModel::closeBulkTransferDialog
        )
    }

    // Live Camera Barcode Scanner
    if (uiState.isScannerOpen) {
        val scannerTitle = when (uiState.scannerTarget) {
            ScannerTarget.BARCODE -> "Barkod Tara"
            ScannerTarget.LOCATION -> "Raf / Lokasyon Tara"
            ScannerTarget.TRANSFER_SOURCE -> "Kaynak Raf Tara"
            ScannerTarget.TRANSFER_TARGET -> "Hedef Raf Tara"
        }

        LiveBarcodeScannerDialog(
            title = scannerTitle,
            onBarcodeScanned = { scannedCode ->
                viewModel.onBarcodeDetected(scannedCode)
            },
            onDismiss = {
                viewModel.closeScanner()
            }
        )
    }
}
