package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class StockRepository(
    private val stockDao: StockDao
) {
    val allStockItems: Flow<List<StockItemEntity>> = stockDao.getAllStockItems()
    val allLocations: Flow<List<String>> = stockDao.getAllLocations()
    val recentLogs: Flow<List<AuditLogEntity>> = stockDao.getRecentLogs()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun assignProduct(
        barcode: String,
        location: String,
        photoUri: String? = null,
        quantity: Int = 1,
        productName: String? = null,
        notes: String? = null
    ): Result<StockItemEntity> = withContext(Dispatchers.IO) {
        val trimmedBarcode = barcode.trim()
        val trimmedLocation = location.trim().uppercase(Locale("tr", "TR"))

        if (trimmedBarcode.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Barkod alanı boş olamaz."))
        }
        if (trimmedLocation.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Lokasyon alanı boş olamaz."))
        }

        val existing = stockDao.findExact(trimmedBarcode, trimmedLocation)
        val finalQuantity = if (existing != null) existing.quantity + quantity else quantity
        val finalPhoto = photoUri ?: existing?.photoUri
        val finalName = productName ?: existing?.productName

        val entity = StockItemEntity(
            id = existing?.id ?: 0,
            barcode = trimmedBarcode,
            location = trimmedLocation,
            productName = finalName,
            quantity = finalQuantity,
            photoUri = finalPhoto,
            updatedAt = System.currentTimeMillis(),
            notes = notes ?: existing?.notes
        )

        stockDao.insertOrUpdate(entity)

        stockDao.insertLog(
            AuditLogEntity(
                actionType = "ATA",
                barcode = trimmedBarcode,
                location = trimmedLocation,
                details = "Ürün '$trimmedLocation' konumuna atandı (Adet: $finalQuantity)"
            )
        )

        Result.success(entity)
    }

    suspend fun findLocationsByBarcode(barcode: String): Result<List<StockItemEntity>> = withContext(Dispatchers.IO) {
        val trimmed = barcode.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Barkod alanı boş olamaz."))
        }

        val items = stockDao.getItemsByBarcode(trimmed)

        stockDao.insertLog(
            AuditLogEntity(
                actionType = "BUL",
                barcode = trimmed,
                location = items.firstOrNull()?.location,
                details = if (items.isNotEmpty()) {
                    "Konum(lar) bulundu: " + items.joinToString(", ") { "${it.location} (${it.quantity} adet)" }
                } else {
                    "Kayıtlı konum bulunamadı."
                }
            )
        )

        Result.success(items)
    }

    suspend fun deleteProduct(barcode: String, location: String? = null): Result<Int> = withContext(Dispatchers.IO) {
        val trimmedBarcode = barcode.trim()
        val trimmedLocation = location?.trim()?.uppercase(Locale("tr", "TR"))

        if (trimmedBarcode.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Barkod alanı boş olamaz."))
        }

        val deletedCount = if (!trimmedLocation.isNullOrEmpty()) {
            stockDao.deleteByBarcodeAndLocation(trimmedBarcode, trimmedLocation)
        } else {
            stockDao.deleteByBarcode(trimmedBarcode)
        }

        if (deletedCount > 0) {
            stockDao.insertLog(
                AuditLogEntity(
                    actionType = "SİL",
                    barcode = trimmedBarcode,
                    location = trimmedLocation,
                    details = "Ürün sistemden silindi (Etkilenen: $deletedCount kayıt)"
                )
            )
            Result.success(deletedCount)
        } else {
            Result.failure(NoSuchElementException("Silinecek ürün bulunamadı: $trimmedBarcode"))
        }
    }

    suspend fun updateQuantity(item: StockItemEntity, newQuantity: Int) = withContext(Dispatchers.IO) {
        if (newQuantity <= 0) {
            stockDao.deleteItem(item)
            stockDao.insertLog(
                AuditLogEntity(
                    actionType = "SİL",
                    barcode = item.barcode,
                    location = item.location,
                    details = "Adet sıfırlandığı için ürün silindi: ${item.barcode} (${item.location})"
                )
            )
        } else {
            stockDao.insertOrUpdate(item.copy(quantity = newQuantity, updatedAt = System.currentTimeMillis()))
            stockDao.insertLog(
                AuditLogEntity(
                    actionType = "GÜNCELLE",
                    barcode = item.barcode,
                    location = item.location,
                    details = "Adet güncellendi: $newQuantity adet"
                )
            )
        }
    }

    suspend fun bulkTransferLocation(
        sourceLocation: String,
        targetLocation: String,
        selectedItemIds: Set<Long>? = null
    ): Result<Int> = withContext(Dispatchers.IO) {
        val trimmedSource = sourceLocation.trim().uppercase(Locale("tr", "TR"))
        val trimmedTarget = targetLocation.trim().uppercase(Locale("tr", "TR"))

        if (trimmedSource.isEmpty() || trimmedTarget.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Kaynak ve hedef lokasyon seçilmelidir."))
        }
        if (trimmedSource == trimmedTarget) {
            return@withContext Result.failure(IllegalArgumentException("Kaynak ve hedef lokasyon aynı olamaz."))
        }

        val sourceItems = stockDao.getItemsByLocationSync(trimmedSource)
        val itemsToMove = if (selectedItemIds.isNullOrEmpty()) {
            sourceItems
        } else {
            sourceItems.filter { it.id in selectedItemIds }
        }

        if (itemsToMove.isEmpty()) {
            return@withContext Result.failure(NoSuchElementException("'$trimmedSource' lokasyonunda taşınacak ürün bulunamadı."))
        }

        var movedQuantityTotal = 0
        var movedItemCount = 0

        for (item in itemsToMove) {
            val existingAtTarget = stockDao.findExact(item.barcode, trimmedTarget)
            if (existingAtTarget != null) {
                val merged = existingAtTarget.copy(
                    quantity = existingAtTarget.quantity + item.quantity,
                    photoUri = existingAtTarget.photoUri ?: item.photoUri,
                    updatedAt = System.currentTimeMillis()
                )
                stockDao.insertOrUpdate(merged)
                stockDao.deleteItem(item)
            } else {
                val updated = item.copy(
                    location = trimmedTarget,
                    updatedAt = System.currentTimeMillis()
                )
                stockDao.insertOrUpdate(updated)
            }
            movedQuantityTotal += item.quantity
            movedItemCount++
        }

        stockDao.insertLog(
            AuditLogEntity(
                actionType = "TAŞI",
                barcode = "$movedItemCount Çeşit Ürün",
                location = "$trimmedSource ➔ $trimmedTarget",
                details = "Toplu Taşıma: $trimmedSource ➔ $trimmedTarget ($movedQuantityTotal adet / $movedItemCount çeşit ürün aktarıldı)"
            )
        )

        Result.success(movedQuantityTotal)
    }

    suspend fun getItemsAtLocation(location: String): List<StockItemEntity> = withContext(Dispatchers.IO) {
        stockDao.getItemsByLocationSync(location.trim().uppercase(Locale("tr", "TR")))
    }

    suspend fun exportCsv(items: List<StockItemEntity>): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        sb.append("Barkod,Lokasyon,Adet,Ürün Adı,Tarih,Notlar\n")
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        for (item in items) {
            val dateStr = sdf.format(Date(item.updatedAt))
            sb.append("\"${item.barcode}\",\"${item.location}\",${item.quantity},\"${item.productName ?: ""}\",\"$dateStr\",\"${item.notes ?: ""}\"\n")
        }
        sb.toString()
    }

    suspend fun seedSampleDataIfEmpty() = withContext(Dispatchers.IO) {
        val items = stockDao.getAllStockItems().firstOrNull()
        if (items.isNullOrEmpty()) {
            val sampleItems = listOf(
                StockItemEntity(barcode = "8690123456789", location = "RAF-A1", productName = "Spor Ayakkabı Siyah 42", quantity = 3),
                StockItemEntity(barcode = "8690987654321", location = "RAF-A2", productName = "Klasik Deri Ayakkabı Kahve 41", quantity = 2),
                StockItemEntity(barcode = "NK-AIR-9921", location = "DEPO-B4", productName = "Koşu Ayakkabısı Beyaz 43", quantity = 5),
                StockItemEntity(barcode = "PUM-77341", location = "RAF-C1", productName = "Antrenman Tişörtü Siyah L", quantity = 8),
                StockItemEntity(barcode = "AD-BOOST-102", location = "RAF-B3", productName = "Sneaker Gri 40", quantity = 4)
            )
            for (item in sampleItems) {
                stockDao.insertOrUpdate(item)
            }
            stockDao.insertLog(
                AuditLogEntity(
                    actionType = "ATA",
                    barcode = "8690123456789",
                    location = "RAF-A1",
                    details = "Başlangıç örnek stok verileri yüklendi."
                )
            )
        }
    }
}
