package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val actionType: String, // "ATA", "BUL", "SİL"
    val barcode: String,
    val location: String?,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String
)
