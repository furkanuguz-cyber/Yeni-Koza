package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warehouse Luxury Dark Theme Palette (Yeni Koza)
val KozaDarkBackground = Color(0xFF111113)
val KozaCardBackground = Color(0xFF1A1A1E)
val KozaCardOverlay = Color(0xF21A1A1E)
val KozaInputBackground = Color(0xCC242428)
val KozaInputBorder = Color(0xFF38383E)
val KozaInputBorderFocused = Color(0xFFE5E7EB)

val KozaPrimaryWhite = Color(0xFFFFFFFF)
val KozaOnPrimaryBlack = Color(0xFF111113)
val KozaButtonHover = Color(0xFFE5E7EB)

val KozaDangerRed = Color(0xFFB91C1C)
val KozaDangerRedHover = Color(0xFF991B1B)
val KozaSuccessGreen = Color(0xFF16A34A)
val KozaWarningAmber = Color(0xFFD97706)
val KozaAccentCyan = Color(0xFF06B6D4)

val KozaTextPrimary = Color(0xFFF9FAFB)
val KozaTextSecondary = Color(0xFF9CA3AF)
val KozaTextMuted = Color(0xFF6B7280)
