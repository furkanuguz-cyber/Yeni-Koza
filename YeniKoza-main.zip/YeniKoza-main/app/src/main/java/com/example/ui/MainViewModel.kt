package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.camera.BarcodeImageUtils
import com.example.data.AuditLogEntity
import com.example.data.StockItemEntity
import com.example.data.StockRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class StatusType {
    IDLE,
    LOADING,
    SUCCESS,
    FOUND,
    ERROR
}

enum class ScannerTarget {
    BARCODE,
    LOCATION,
    TRANSFER_SOURCE,
    TRANSFER_TARGET
}

enum class AppTab {
    MAIN_CARD,
    INVENTORY_LIST,
    HISTORY,
    WEB_PANEL
}

data class UiState(
    val barcodeInput: String = "",
    val locationInput: String = "",
    val labelPhotoUri: Uri? = null,
    val isProcessingPhoto: Boolean = false,
    val statusMessage: String? = null,
    val statusType: StatusType = StatusType.IDLE,
    val foundLocations: List<StockItemEntity> = emptyList(),
    val isScannerOpen: Boolean = false,
    val scannerTarget: ScannerTarget = ScannerTarget.BARCODE,
    val activeTab: AppTab = AppTab.MAIN_CARD,
    val googleAppsScriptUrl: String = "https://script.google.com/macros/s/AKfycbxcY0-dyRIM5ktbHWDWUa3EPP5z1I_T7BT6MnuxSKM8yfSIWu2U3JL4GUgIFzSV5p-60Q/exec",
    val searchQuery: String = "",
    val selectedLocationFilter: String? = null,
    val showBulkTransferDialog: Boolean = false,
    val transferSourceLocation: String = "",
    val transferTargetLocation: String = "",
    val transferSourceItems: List<StockItemEntity> = emptyList(),
    val selectedTransferItemIds: Set<Long> = emptySet(),
    val isTransferring: Boolean = false,
    val transferStatusMessage: String? = null
)

class MainViewModel(
    private val repository: StockRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val allStockItems: StateFlow<List<StockItemEntity>> = repository.allStockItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLocations: StateFlow<List<String>> = repository.allLocations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentLogs: StateFlow<List<AuditLogEntity>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
        }
    }

    fun onBarcodeChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            barcodeInput = value,
            statusMessage = null,
            statusType = StatusType.IDLE
        )
    }

    fun onLocationChanged(value: String) {
        _uiState.value = _uiState.value.copy(
            locationInput = value,
            statusMessage = null,
            statusType = StatusType.IDLE
        )
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setLocationFilter(location: String?) {
        _uiState.value = _uiState.value.copy(selectedLocationFilter = location)
    }

    fun setActiveTab(tab: AppTab) {
        _uiState.value = _uiState.value.copy(activeTab = tab)
    }

    fun openScanner(target: ScannerTarget) {
        _uiState.value = _uiState.value.copy(
            isScannerOpen = true,
            scannerTarget = target
        )
    }

    fun closeScanner() {
        _uiState.value = _uiState.value.copy(isScannerOpen = false)
    }

    fun onBarcodeDetected(detected: String) {
        val trimmed = detected.trim()
        when (_uiState.value.scannerTarget) {
            ScannerTarget.BARCODE -> {
                _uiState.value = _uiState.value.copy(
                    barcodeInput = trimmed,
                    statusMessage = "✅ Barkod okundu: $trimmed",
                    statusType = StatusType.SUCCESS,
                    isScannerOpen = false
                )
            }
            ScannerTarget.LOCATION -> {
                _uiState.value = _uiState.value.copy(
                    locationInput = trimmed,
                    statusMessage = "✅ Lokasyon okundu: $trimmed",
                    statusType = StatusType.SUCCESS,
                    isScannerOpen = false
                )
            }
            ScannerTarget.TRANSFER_SOURCE -> {
                setTransferSource(trimmed)
                _uiState.value = _uiState.value.copy(isScannerOpen = false)
            }
            ScannerTarget.TRANSFER_TARGET -> {
                setTransferTarget(trimmed)
                _uiState.value = _uiState.value.copy(isScannerOpen = false)
            }
        }
    }

    fun processCapturedPhoto(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isProcessingPhoto = true,
                statusMessage = "⏳ Fotoğraf taranıyor...",
                statusType = StatusType.LOADING
            )

            val savedUri = BarcodeImageUtils.copyImageToAppStorage(context, uri) ?: uri
            val detectedBarcode = BarcodeImageUtils.detectBarcodeFromUri(context, savedUri)

            if (!detectedBarcode.isNullOrBlank()) {
                _uiState.value = _uiState.value.copy(
                    labelPhotoUri = savedUri,
                    barcodeInput = detectedBarcode,
                    isProcessingPhoto = false,
                    statusMessage = "✅ Barkod Otomatik Okundu!",
                    statusType = StatusType.SUCCESS
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    labelPhotoUri = savedUri,
                    isProcessingPhoto = false,
                    statusMessage = "⚠️ Fotoğraf yüklendi. Barkod algılanamadıysa manuel girebilirsiniz.",
                    statusType = StatusType.IDLE
                )
            }
        }
    }

    fun clearPhoto() {
        _uiState.value = _uiState.value.copy(labelPhotoUri = null)
    }

    fun assignProduct(quantity: Int = 1) {
        val barcode = _uiState.value.barcodeInput.trim()
        val location = _uiState.value.locationInput.trim()

        if (barcode.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⚠️ Lütfen barkod alanını doldurun.",
                statusType = StatusType.ERROR
            )
            return
        }
        if (location.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⚠️ Lütfen lokasyon alanını doldurun.",
                statusType = StatusType.ERROR
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⏳ İşlem yapılıyor...",
                statusType = StatusType.LOADING
            )

            val photoUriString = _uiState.value.labelPhotoUri?.toString()
            val result = repository.assignProduct(
                barcode = barcode,
                location = location,
                photoUri = photoUriString,
                quantity = quantity
            )

            result.onSuccess { item ->
                _uiState.value = _uiState.value.copy(
                    statusMessage = "✅ Ürün '${item.location}' konumuna atandı!",
                    statusType = StatusType.SUCCESS,
                    foundLocations = listOf(item)
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    statusMessage = "❌ Hata: ${err.message}",
                    statusType = StatusType.ERROR
                )
            }
        }
    }

    fun findLocation() {
        val barcode = _uiState.value.barcodeInput.trim()
        if (barcode.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⚠️ Lütfen barkod alanını doldurun.",
                statusType = StatusType.ERROR
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⏳ Konum aranıyor...",
                statusType = StatusType.LOADING
            )

            val result = repository.findLocationsByBarcode(barcode)
            result.onSuccess { items ->
                if (items.isNotEmpty()) {
                    val locSummary = items.joinToString(", ") { "${it.location} (${it.quantity} adet)" }
                    _uiState.value = _uiState.value.copy(
                        statusMessage = "📍 Konum: $locSummary",
                        statusType = StatusType.FOUND,
                        foundLocations = items,
                        locationInput = items.first().location
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        statusMessage = "❌ Ürün bulunamadı: $barcode",
                        statusType = StatusType.ERROR,
                        foundLocations = emptyList()
                    )
                }
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    statusMessage = "❌ Hata: ${err.message}",
                    statusType = StatusType.ERROR
                )
            }
        }
    }

    fun deleteProduct() {
        val barcode = _uiState.value.barcodeInput.trim()
        val location = _uiState.value.locationInput.trim()

        if (barcode.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⚠️ Lütfen silinecek ürünün barkodunu girin.",
                statusType = StatusType.ERROR
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                statusMessage = "⏳ Siliniyor...",
                statusType = StatusType.LOADING
            )

            val result = repository.deleteProduct(
                barcode = barcode,
                location = location.ifEmpty { null }
            )

            result.onSuccess { count ->
                _uiState.value = _uiState.value.copy(
                    statusMessage = "🗑️ Ürün silindi ($count kayıt kaldırıldı).",
                    statusType = StatusType.SUCCESS,
                    foundLocations = emptyList(),
                    labelPhotoUri = null
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    statusMessage = "❌ Silinemedi: ${err.message}",
                    statusType = StatusType.ERROR
                )
            }
        }
    }

    fun updateQuantity(item: StockItemEntity, newQuantity: Int) {
        viewModelScope.launch {
            repository.updateQuantity(item, newQuantity)
        }
    }

    fun deleteSpecificItem(item: StockItemEntity) {
        viewModelScope.launch {
            repository.deleteProduct(item.barcode, item.location)
        }
    }

    fun shareCsvExport(context: Context) {
        viewModelScope.launch {
            val items = allStockItems.value
            val csv = repository.exportCsv(items)
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, csv)
                putExtra(Intent.EXTRA_SUBJECT, "Yeni Koza Stok Listesi")
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "Stok Listesini Paylaş")
            context.startActivity(shareIntent)
        }
    }

    fun openBulkTransferDialog(initialSource: String? = null) {
        val src = initialSource ?: _uiState.value.locationInput.ifEmpty { "" }
        _uiState.value = _uiState.value.copy(
            showBulkTransferDialog = true,
            transferSourceLocation = src,
            transferTargetLocation = "",
            transferStatusMessage = null,
            selectedTransferItemIds = emptySet()
        )
        if (src.isNotBlank()) {
            loadTransferSourceItems(src)
        } else {
            _uiState.value = _uiState.value.copy(transferSourceItems = emptyList())
        }
    }

    fun closeBulkTransferDialog() {
        _uiState.value = _uiState.value.copy(
            showBulkTransferDialog = false,
            transferStatusMessage = null
        )
    }

    fun setTransferSource(location: String) {
        _uiState.value = _uiState.value.copy(
            transferSourceLocation = location,
            transferStatusMessage = null
        )
        loadTransferSourceItems(location)
    }

    fun setTransferTarget(location: String) {
        _uiState.value = _uiState.value.copy(
            transferTargetLocation = location,
            transferStatusMessage = null
        )
    }

    private fun loadTransferSourceItems(location: String) {
        viewModelScope.launch {
            val items = repository.getItemsAtLocation(location)
            _uiState.value = _uiState.value.copy(
                transferSourceItems = items,
                selectedTransferItemIds = items.map { it.id }.toSet()
            )
        }
    }

    fun toggleTransferItemSelection(itemId: Long) {
        val current = _uiState.value.selectedTransferItemIds.toMutableSet()
        if (current.contains(itemId)) {
            current.remove(itemId)
        } else {
            current.add(itemId)
        }
        _uiState.value = _uiState.value.copy(selectedTransferItemIds = current)
    }

    fun toggleSelectAllTransferItems(selectAll: Boolean) {
        val allIds = if (selectAll) {
            _uiState.value.transferSourceItems.map { it.id }.toSet()
        } else {
            emptySet()
        }
        _uiState.value = _uiState.value.copy(selectedTransferItemIds = allIds)
    }

    fun executeBulkTransfer() {
        val source = _uiState.value.transferSourceLocation.trim()
        val target = _uiState.value.transferTargetLocation.trim()
        val selectedIds = _uiState.value.selectedTransferItemIds

        if (source.isEmpty() || target.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                transferStatusMessage = "⚠️ Kaynak ve hedef lokasyon girilmelidir."
            )
            return
        }

        if (source.equals(target, ignoreCase = true)) {
            _uiState.value = _uiState.value.copy(
                transferStatusMessage = "⚠️ Kaynak ve hedef lokasyon aynı olamaz."
            )
            return
        }

        if (selectedIds.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                transferStatusMessage = "⚠️ Lütfen taşınacak en az 1 ürün seçin."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isTransferring = true, transferStatusMessage = null)
            val result = repository.bulkTransferLocation(source, target, selectedIds)

            result.onSuccess { movedCount ->
                _uiState.value = _uiState.value.copy(
                    isTransferring = false,
                    showBulkTransferDialog = false,
                    statusMessage = "✅ Toplu Taşıma Tamamlandı: $source ➔ $target ($movedCount adet ürün)",
                    statusType = StatusType.SUCCESS
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isTransferring = false,
                    transferStatusMessage = "❌ Hata: ${err.message}"
                )
            }
        }
    }

    fun fillSampleItem(barcode: String, location: String) {
        _uiState.value = _uiState.value.copy(
            barcodeInput = barcode,
            locationInput = location
        )
    }

    class Factory(private val repository: StockRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository) as T
        }
    }
}
