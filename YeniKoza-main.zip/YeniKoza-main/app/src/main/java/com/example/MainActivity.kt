package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.AppDatabase
import com.example.data.StockRepository
import com.example.ui.MainAppScreen
import com.example.ui.MainViewModel
import com.example.ui.theme.YeniKozaTheme

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = StockRepository(database.stockDao())
        val factory = MainViewModel.Factory(repository)
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        setContent {
            YeniKozaTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}
