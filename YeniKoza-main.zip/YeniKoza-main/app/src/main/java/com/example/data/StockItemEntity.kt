package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "stock_items",
    indices = [
        Index(value = ["barcode"]),
        Index(value = ["location"])
    ]
)
data class StockItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val barcode: String,
    val location: String,
    val productName: String? = null,
    val quantity: Int = 1,
    val photoUri: String? = null,
    val updatedAt: Long = System.currentTimeMillis(),
    val notes: String? = null
)
