package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = KozaPrimaryWhite,
    onPrimary = KozaOnPrimaryBlack,
    primaryContainer = Color(0xFF27272A),
    onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = KozaAccentCyan,
    onSecondary = Color(0xFF000000),
    background = KozaDarkBackground,
    onBackground = KozaTextPrimary,
    surface = KozaCardBackground,
    onSurface = KozaTextPrimary,
    surfaceVariant = KozaInputBackground,
    onSurfaceVariant = KozaTextSecondary,
    error = KozaDangerRed,
    onError = Color.White
)

@Composable
fun YeniKozaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
