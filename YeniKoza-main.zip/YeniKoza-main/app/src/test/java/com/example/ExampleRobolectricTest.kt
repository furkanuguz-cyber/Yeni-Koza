package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.StockRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  private lateinit var db: AppDatabase
  private lateinit var repository: StockRepository

  @Before
  fun setUp() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
        .allowMainThreadQueries()
        .build()
    repository = StockRepository(db.stockDao())
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Yeni Koza", appName)
  }

  @Test
  fun `test bulk transfer between locations`() = runBlocking {
    repository.assignProduct("BARCODE-001", "RAF-A", quantity = 5)
    repository.assignProduct("BARCODE-002", "RAF-A", quantity = 3)

    val result = repository.bulkTransferLocation("RAF-A", "RAF-B")
    assertTrue(result.isSuccess)
    assertEquals(8, result.getOrNull())

    val itemsAtB = repository.getItemsAtLocation("RAF-B")
    assertEquals(2, itemsAtB.size)

    val itemsAtA = repository.getItemsAtLocation("RAF-A")
    assertEquals(0, itemsAtA.size)
  }
}
